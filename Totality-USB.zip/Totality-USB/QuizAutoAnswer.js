/* QuizAutoAnswer.js — Totality auto-answer payload
 *
 * Paste whole file into DevTools console (or inject via
 * BrowserControl.ExecuteJavaScript / frame.ExecuteJavaScriptAsync), then:
 *
 *   __quizDetect('focused')  -> JSON: question(s) in scope with type + options
 *   __quizDetect('all')      -> JSON: every question on the page
 *   __quizDetect('single:2') -> JSON: only question index 2
 *   __quizApply(json)        -> JSON: per-question apply + verify results
 *   __quizReady(3000)        -> Promise<boolean>: true once >=1 question exists
 *
 * NATIVE WORKFLOW (Ctrl+Y handler in dllmain.cpp):
 *   1. SCRAPE  EvaluateScriptAsync(file + "__quizDetect('focused')")
 *              -> parse descriptors [{index, quizType, answerType, prompt, options, subfields}]
 *              -> if zero questions, retry: __quizReady(3000) then detect again
 *                 (covers deferred/AJAX-rendered quizzes). If still zero, abort
 *                 and fall back to existing clipboard-AI overlay (manual path).
 *   2. PROMPT  Build one AI prompt per question, shaped by quizType:
 *              - multichoice_single / truefalse : prompt + lettered options,
 *                instruct "reply with the single letter only (e.g. C)".
 *              - multichoice_multi              : "reply with letters only, comma-separated (e.g. A,C)".
 *              - shortanswer / numerical        : prompt only, "reply with the exact value only".
 *              - essay                          : prompt only, full answer expected.
 *              - matching                       : rows + shared options as JSON,
 *                "reply with a JSON object mapping each row to its option".
 *              - cloze_embedded                 : subfields in order, "reply with JSON array in order".
 *              - select_single                  : like multichoice_single.
 *              Send via existing GeminiChat::RequestQuickResponse on a worker
 *              thread (same pattern as TriggerClipboardAiWorkflow).
 *   3. PARSE   Normalize AI text per quizType:
 *              letters -> uppercase, strip dots/parens ("C." / "(C)" -> "C");
 *              matching/cloze -> JSON.parse with fallback to line-split.
+ *              ddwtos_gapfill -> ordered array of choice texts, one per gap.
+ *              visualOptions:true (options are [img:...]) -> route to the
+ *              screenshot/vision workflow instead of text AI; letter-index
+ *              apply still works once the letter is known.
 *              On parse failure: keep raw text (text types accept anything) or
 *              abort that question and report it for manual answering.
 *   4. APPLY   EvaluateScriptAsync("__quizApply('" + escapedJson + "')")
 *              -> per-item {index, ok, verified, detail}. Apply matches options
 *                BY TEXT (fuzzy) or by letter mapped to CURRENT DOM order, so
 *                Moodle's shuffled options can't misalign the click.
 *   5. VERIFY  If any item has verified:false, retry that item once (re-detect
 *              first — navigation may have re-rendered). Still failing -> show
 *              in overlay for manual handling, do NOT blind-click elsewhere.
 *
 * SCOPE RULES:
 *   - 'focused' (default for Ctrl+Y): answers the question containing
 *     document.activeElement (click/type into it). If focus is nowhere
 *     (pure scrolling), targets the question nearest the viewport center
 *     instead of defaulting to question 0. Final fallback: first question.
 *   - 'all': every detected question on the page. Use for all-on-one-page
 *     quizzes. Each question is scraped/applied independently by index, so a
 *     failure on Q3 never touches Q1/Q2/Q5.
 *   - 'single:N': explicit index override.
 *
 * EDGE CASES HANDLED HERE (JS side):
 *   [E1] option order shuffled per attempt      -> match by text, never by stored index
 *   [E2] Moodle "Clear my choice" radio        -> excluded from options
 *   [E3] placeholder "Choose..." in selects    -> excluded, never selected
 *   [E4] TinyMCE/Atto rich-text iframes        -> written via iframe document, fallback to textarea
 *   [E5] React-controlled inputs               -> native value-setter hack + input/change events
 *   [E6] disabled/readonly fields              -> reported {ok:false}, skipped, never forced
 *   [E7] matching rows sharing one option pool -> each row matched independently by row text
 *   [E8] cloze (embedded answers in passage)   -> subfields answered in DOM order
 *  [E9] re-paste safe                         -> no globals clobbered, cache rebuilt per call
 * [E10] ES5-only syntax                       -> runs on whatever Chromium SEB ships
 * [E11] ddwtos drag-drop gaps                 -> choices scraped from .draghome items,
 *                                               hidden _pN inputs written directly (grading
 *                                               reads those, not the drag visuals)
 * [E12] image-only options/rows (icons)       -> reported as [img: alt|file] with
 *                                               visualOptions:true; letter apply unaffected
 */

function __quizVisible(el) {
    if (!el || el.disabled) return false;
    if (el.type === 'hidden') return false;
    var r = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
    if (r && (r.width === 0 || r.height === 0)) {
        var cs = window.getComputedStyle ? window.getComputedStyle(el) : null;
        if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return false;
    }
    return true;
}

function __quizText(el) {
    if (!el) return '';
    var t = el.innerText || el.textContent || '';
    return t.replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
}

function __quizCleanLabel(s) {
    // strip Moodle "a. ", "b) " prefixes and trailing whitespace
    return (s || '').replace(/^\s*[a-zA-Z][\.\)\:\-]\s*/, '').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
}

function __quizIsSearchContainer(el) {
    if (!el || el === document.body || el === document.documentElement) return false;
    if (el.getAttribute && el.getAttribute('role') === 'search') return true;
    try {
        if (el.querySelector && el.querySelector('input[type="search"]')) return true;
    } catch (e) {}
    var act = (el.getAttribute && el.getAttribute('action')) || '';
    if (/search/i.test(act)) return true;
    return false;
}

function __quizIsSkippableText(el) {
    if (!el) return true;
    var type = (el.getAttribute && el.getAttribute('type')) || el.type || 'text';
    type = String(type).toLowerCase();
    // search boxes, logins and hidden fields are never quiz answers
    if (type === 'search' || type === 'password' || type === 'hidden' || type === 'submit' || type === 'button') return true;
    var hay = ((el.name || '') + ' ' + (el.id || '') + ' ' + (el.placeholder || '') + ' ' +
               ((el.getAttribute && el.getAttribute('aria-label')) || '')).toLowerCase();
    if (/\bsearch\b/.test(hay)) return true;
    // chrome areas (header/nav/footer/banners) are never quiz content
    var p = el;
    while (p && p !== document.body) {
        var tag = (p.tagName || '').toLowerCase();
        if (tag === 'header' || tag === 'nav' || tag === 'footer') return true;
        var role = p.getAttribute ? (p.getAttribute('role') || '').toLowerCase() : '';
        if (role === 'search' || role === 'banner' || role === 'navigation') return true;
        p = p.parentElement;
    }
    return false;
}

function __quizFindRoots() {
    var roots = [];
    var i;
    // Primary: Moodle question blocks.
    var moodle = document.querySelectorAll('.que');
    for (i = 0; i < moodle.length; i++) roots.push(moodle[i]);
    if (roots.length) return roots;
    // Generic: fieldsets with legends, then forms, then whole body.
    // Search/login containers are skipped: a lone search box is not a quiz.
    var sets = document.querySelectorAll('fieldset');
    for (i = 0; i < sets.length; i++) {
        if (__quizIsSearchContainer(sets[i])) continue;
        if (sets[i].querySelector('input,select,textarea')) roots.push(sets[i]);
    }
    if (roots.length) return roots;
    var forms = document.querySelectorAll('form');
    for (i = 0; i < forms.length; i++) {
        if (__quizIsSearchContainer(forms[i])) continue;
        if (forms[i].querySelector('input,select,textarea')) roots.push(forms[i]);
    }
    if (roots.length) return roots;
    return [document.body];
}

function __quizImgNote(container) {
    // Image-only options/rows (icons, screenshots): expose alt text or file
    // name so the AI layer knows this slot needs vision. Letter-index apply
    // still works regardless.
    if (!container || !container.querySelector) return '';
    try {
        var img = container.querySelector('img');
        if (!img) return '';
        var alt = ((img.getAttribute && img.getAttribute('alt')) || '').replace(/^\s+|\s+$/g, '');
        if (alt) return '[img: ' + alt + ']';
        var src = (img.getAttribute && img.getAttribute('src')) || '';
        var m = /([^\/\?#]+?)(\?.*)?$/.exec(src);
        return '[img: ' + (m ? m[1] : 'image') + ']';
    } catch (e) { return '[image]'; }
}

function __quizLabelFor(input) {
    // Moodle 5.x: no <label> — input references a div via aria-labelledby.
    try {
        var by = input.getAttribute && input.getAttribute('aria-labelledby');
        if (by) {
            var ids = by.split(/\s+/);
            var parts = [];
            for (var b = 0; b < ids.length; b++) {
                if (!ids[b]) continue;
                var ref = document.getElementById(ids[b]);
                if (ref) parts.push(__quizText(ref));
            }
            var joined = __quizCleanLabel(parts.join(' '));
            if (joined) return joined;
        }
        var al = input.getAttribute && input.getAttribute('aria-label');
        if (al && __quizCleanLabel(al)) return __quizCleanLabel(al);
    } catch (e) {}
    if (input.id) {
        var l = document.querySelector('label[for="' + input.id + '"]');
        if (l) {
            var lt = __quizCleanLabel(__quizText(l));
            if (lt) return lt;
            var note = __quizImgNote(l);
            if (note) return note;
        }
    }
    var p = input.parentElement;
    while (p) {
        var tag = (p.tagName || '').toLowerCase();
        if (tag === 'label') return __quizCleanLabel(__quizText(p));
        if (tag === 'div' || tag === 'li' || tag === 'tr' || tag === 'fieldset') {
            var inner = p.querySelector('label');
            if (inner) return __quizCleanLabel(__quizText(inner));
            break;
        }
        p = p.parentElement;
    }
    // Image-only option: fall back to alt/filename placeholder.
    var c = input.parentElement;
    if (c) return __quizImgNote(c.parentElement && c.parentElement !== document ? c.parentElement : c);
    return '';
}

function __quizCollectRadios(root) {
    var out = [];
    var inputs = root.querySelectorAll('input[type="radio"]');
    for (var i = 0; i < inputs.length; i++) {
        var el = inputs[i];
        if (!__quizVisible(el)) continue;
        // [E2] skip Moodle "Clear my choice".
        var lbl = __quizLabelFor(el);
        if (!el.value || /clear my choice/i.test(lbl)) continue;
        out.push({ el: el, label: lbl, name: el.name || '' });
    }
    return out;
}

function __quizCollectChecks(root) {
    var out = [];
    var inputs = root.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < inputs.length; i++) {
        var el = inputs[i];
        if (!__quizVisible(el)) continue;
        out.push({ el: el, label: __quizLabelFor(el), name: el.name || '' });
    }
    return out;
}

function __quizCollectSelects(root, excludeUnits) {
    var out = [];
    var sels = root.querySelectorAll('select');
    for (var i = 0; i < sels.length; i++) {
        var el = sels[i];
        if (!__quizVisible(el)) continue;
        if (el.disabled || el.readOnly) continue;
        var opts = [];
        for (var j = 0; j < el.options.length; j++) {
            var t = __quizText(el.options[j]);
            if (!t || /^(choose|select|--|pick)/i.test(t)) continue; // [E3]
            opts.push(t);
        }
        if (!opts.length && !excludeUnits) continue;
        out.push({ el: el, options: opts });
    }
    return out;
}

function __quizCollectTexts(root) {
    var out = [];
    var inputs = root.querySelectorAll('input[type="text"], input[type="number"], input[type="search"], input:not([type])');
    for (var i = 0; i < inputs.length; i++) {
        var el = inputs[i];
        if (!__quizVisible(el) || el.disabled || el.readOnly) continue;
        if (__quizIsSkippableText(el)) continue;
        out.push(el);
    }
    return out;
}

function __quizCollectAreas(root) {
    var out = [];
    var areas = root.querySelectorAll('textarea');
    for (var i = 0; i < areas.length; i++) {
        var el = areas[i];
        if (!__quizVisible(el) || el.disabled || el.readOnly) continue;
        out.push(el);
    }
    return out;
}

function __quizPromptFor(root) {
    var cands = ['.qtext', '.formulation .qtext', 'legend', '.questiontext', 'h1,h2,h3'];
    for (var i = 0; i < cands.length; i++) {
        var el = root.querySelector(cands[i]);
        var t = __quizText(el);
        if (t && t.length > 3) return t.slice(0, 2000);
    }
    // Generic fallback: prefer main content over header/nav chrome.
    var mains = ['main [role="main"]', 'main', '[role="main"]', '#page-content', 'article', '.generalbox'];
    for (var m = 0; m < mains.length; m++) {
        try {
            var main = (root === document.body ? document : root).querySelector(mains[m]);
            var mt = __quizText(main);
            if (mt && mt.length > 20) return mt.slice(0, 2000);
        } catch (e) {}
    }
    return __quizText(root).slice(0, 2000);
}

function __quizDdwtosInfo(root) {
    // Moodle drag-and-drop into text: gaps are .drop/.gap spans (or only
    // visible as hidden inputs name="q...:N_pM"), choices live in .draghome
    // items. Grading reads the hidden inputs, so the applier writes those.
    var info = { hasDragMarkup: false, choices: [], gapCount: 0 };
    var seen = {};
    var i, t;
    var drags = root.querySelectorAll('.draghome .choice, .draghome, .draggroup .choice');
    if (!drags.length) {
        var groups = root.querySelectorAll('.draggroup, .draghomes');
        for (var g = 0; g < groups.length; g++) {
            var kids = groups[g].querySelectorAll('span');
            for (var k = 0; k < kids.length; k++) {
                t = __quizCleanLabel(__quizText(kids[k])) || __quizImgNote(kids[k]);
                if (t && !seen[t]) { seen[t] = 1; info.choices.push(t); }
            }
        }
    } else {
        for (i = 0; i < drags.length; i++) {
            t = __quizCleanLabel(__quizText(drags[i])) || __quizImgNote(drags[i]);
            if (t && !seen[t]) { seen[t] = 1; info.choices.push(t); }
        }
    }
    if (drags.length || root.querySelector('.draggroup')) info.hasDragMarkup = true;
    var gaps = root.querySelectorAll('.drop, .gap');
    info.gapCount = gaps.length;
    if (!info.gapCount) {
        var hids = root.querySelectorAll('input[type="hidden"]');
        var n = 0;
        for (i = 0; i < hids.length; i++) if (/_p\d+$/.test(hids[i].name || '')) n++;
        info.gapCount = n;
    }
    return info;
}

function __quizClassify(root) {
    var cls = (root.className || '') + ' ';
    var radios = __quizCollectRadios(root);
    var checks = __quizCollectChecks(root);
    var selects = __quizCollectSelects(root, false);
    var texts = __quizCollectTexts(root);
    var areas = __quizCollectAreas(root);

    function hasMoodle(n) { return cls.indexOf(n) !== -1; }

    // --- Moodle-hinted paths ---
    if (hasMoodle('truefalse') && radios.length) {
        return { quizType: 'truefalse', answerType: 'radio_single', options: ['True', 'False'] };
    }
    if (hasMoodle('multichoice')) {
        if (checks.length && !radios.length) {
            var co = [];
            for (var i = 0; i < checks.length; i++) co.push(checks[i].label);
            return { quizType: 'multichoice_multi', answerType: 'checkbox_multi', options: co };
        }
        if (radios.length) {
            var ro = [];
            for (var j = 0; j < radios.length; j++) ro.push(radios[j].label);
            return { quizType: 'multichoice_single', answerType: 'radio_single', options: ro };
        }
    }
    if ((hasMoodle('shortanswer') || hasMoodle('numerical')) && texts.length) {
        return { quizType: hasMoodle('numerical') ? 'numerical' : 'shortanswer', answerType: 'text_short', options: [] };
    }
    if (hasMoodle('essay') && (areas.length || root.querySelector('iframe'))) {
        return { quizType: 'essay', answerType: areas.length ? 'textarea_essay' : 'richtext_iframe', options: [] };
    }
    if (hasMoodle('match') && selects.length > 1) {
        var rows = [];
        var trs = root.querySelectorAll('table.answer tr, table.generaltable tr');
        for (var r = 0; r < trs.length; r++) {
            var sel = trs[r].querySelector('select');
            if (!sel) continue;
            var qcell = trs[r].querySelector('.text');
            rows.push(__quizText(qcell || trs[r].firstElementChild) || __quizImgNote(trs[r]));
        }
        return { quizType: 'matching', answerType: 'matching_multi_select', options: selects[0].options, rows: rows };
    }
    if ((hasMoodle('multianswer') || hasMoodle('ddwtos') || hasMoodle('gapselect')) &&
        (texts.length + selects.length > 1 || (texts.length + selects.length === 1 && radios.length))) {
        var subs = [];
        var k = 0, s;
        for (s = 0; s < texts.length; s++) subs.push({ sub: k++, kind: 'text' });
        for (s = 0; s < selects.length; s++) subs.push({ sub: k++, kind: 'select', options: selects[s].options });
        if (radios.length) subs.push({ sub: k++, kind: 'radio_group' });
        return { quizType: 'cloze_embedded', answerType: 'cloze_mixed', options: [], subfields: subs };
    }

    // --- drag-and-drop into text (ddwtos): no inputs/selects, only drop
    // zones + drag items + hidden _pN fields. Must run before generic paths.
    var ddInfo = __quizDdwtosInfo(root);
    if ((hasMoodle('ddwtos') || ddInfo.hasDragMarkup) && (ddInfo.gapCount > 0 || ddInfo.choices.length > 1)) {
        return { quizType: 'ddwtos_gapfill', answerType: 'ddwtos_gaps', options: ddInfo.choices, gaps: ddInfo.gapCount };
    }

    // --- Generic (non-Moodle) paths ---
    if (radios.length && !checks.length && !texts.length && !areas.length && selects.length <= 1) {
        var go = [];
        for (var g = 0; g < radios.length; g++) go.push(radios[g].label);
        if (radios.length === 2 && /^(true|false)/i.test(go[0] + go[1])) {
            return { quizType: 'truefalse', answerType: 'radio_single', options: go };
        }
        return { quizType: 'multichoice_single', answerType: 'radio_single', options: go };
    }
    if (checks.length && !radios.length) {
        var gm = [];
        for (var h = 0; h < checks.length; h++) gm.push(checks[h].label);
        return { quizType: 'multichoice_multi', answerType: 'checkbox_multi', options: gm };
    }
    if (selects.length > 1 && !radios.length && !checks.length && !texts.length) {
        return { quizType: 'matching', answerType: 'matching_multi_select', options: selects[0].options, rows: [] };
    }
    if (selects.length === 1 && !radios.length && !checks.length && !texts.length && !areas.length) {
        return { quizType: 'dropdown_select', answerType: 'select_single', options: selects[0].options };
    }
    if (texts.length === 1 && !radios.length && !checks.length && !areas.length && !selects.length) {
        // A lone text field next to a password field is a login form, not a quiz.
        try {
            if (root.querySelector('input[type="password"]')) {
                return { quizType: 'unknown', answerType: 'unknown', options: [] };
            }
        } catch (e) {}
        return { quizType: 'shortanswer', answerType: 'text_short', options: [] };
    }
    if (areas.length >= 1) {
        return { quizType: 'essay', answerType: 'textarea_essay', options: [] };
    }
    if (root.querySelector('iframe') && !radios.length && !checks.length) {
        return { quizType: 'essay', answerType: 'richtext_iframe', options: [] };
    }
    return { quizType: 'unknown', answerType: 'unknown', options: [] };
}

function __quizRootOfFocused(roots) {
    var ae = document.activeElement;
    if (ae && ae !== document.body) {
        for (var i = 0; i < roots.length; i++) {
            if (roots[i] === ae || roots[i].contains(ae)) return i;
        }
    }
    // Fallback: scrolling is not focusing — the user may be looking at a
    // question without ever clicking it. Target the question nearest the
    // viewport vertical center instead of blindly taking question 0.
    var viewH = window.innerHeight || 600;
    var midY = viewH / 2;
    var best = -1, bestDist = 1e9;
    for (var j = 0; j < roots.length; j++) {
        try {
            var r = roots[j].getBoundingClientRect();
            if (!r || r.bottom < 0 || r.top > viewH || r.height <= 0) continue;
            var d = Math.abs((r.top + r.height / 2) - midY);
            if (d < bestDist) { bestDist = d; best = j; }
        } catch (e) {}
    }
    return best;
}

function __quizDescribe(index, root) {
    var info = __quizClassify(root);
    var visual = false;
    var oi;
    for (oi = 0; oi < (info.options || []).length; oi++) {
        if (/^\[img/.test(info.options[oi])) { visual = true; break; }
    }
    return {
        index: index,
        quizType: info.quizType,
        answerType: info.answerType,
        prompt: __quizPromptFor(root),
        options: info.options || [],
        rows: info.rows || [],
        subfields: info.subfields || [],
        gaps: info.gaps || 0,
        visualOptions: visual,
        contextImages: __quizContextImageCount(root)
    };
}

function __quizDetect(scope) {
    scope = scope || 'focused';
    var roots = __quizFindRoots();
    var out = [];
    var i, idx = -1;
    if (scope === 'all') {
        for (i = 0; i < roots.length; i++) out.push(__quizDescribe(i, roots[i]));
    } else if (scope.indexOf('single:') === 0) {
        idx = parseInt(scope.slice(7), 10);
        if (!isNaN(idx) && roots[idx]) out.push(__quizDescribe(idx, roots[idx]));
    } else { // focused
        idx = __quizRootOfFocused(roots);
        if (idx === -1) idx = 0; // fallback: first visible question
        if (roots[idx]) out.push(__quizDescribe(idx, roots[idx]));
    }
    return JSON.stringify({ count: roots.length, scope: scope, questions: out });
}

function __quizReady(timeoutMs) {
    timeoutMs = timeoutMs || 3000;
    return new Promise(function (resolve) {
        if (__quizFindRoots().length && __quizText(document.body).length > 50) { resolve(true); return; }
        var obs = new MutationObserver(function () {
            if (__quizFindRoots().length && __quizText(document.body).length > 50) {
                obs.disconnect(); resolve(true);
            }
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
        setTimeout(function () { obs.disconnect(); resolve(__quizFindRoots().length > 0); }, timeoutMs);
    });
}

// ---------- appliers ----------

function __quizSetValue(el, value) {
    // [E5] native setter hack for framework-controlled inputs.
    try {
        var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        var desc = Object.getOwnPropertyDescriptor(proto, 'value');
        if (desc && desc.set) desc.set.call(el, value);
        else el.value = value;
    } catch (e) { el.value = value; }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
}

function __quizLetterIndex(a) {
    // ONLY a bare letter counts ("B", "c.", "(A)"). Anything longer falls
    // through to fuzzy text match. (Old regex matched the first letter of
    // any word — "Twitter" became letter T=19 and never reached fuzzy.)
    var s = String(a == null ? '' : a).replace(/^\s+|\s+$/g, '');
    if (s.replace(/[^A-Za-z]/g, '').length === 1) {
        var m = /^\(?([A-Za-z])[.\)\:]?\)?$/.exec(s);
        if (m) return m[1].toUpperCase().charCodeAt(0) - 65;
    }
    if (/^\d{1,2}$/.test(s)) {
        var n = parseInt(s, 10);
        if (n >= 1 && n <= 26) return n - 1;
    }
    return -1;
}

function __quizFuzzy(options, want) {
    // [E1] match by text so shuffled order can't misalign.
    var w = __quizCleanLabel(String(want)).toLowerCase();
    if (!w) return -1;
    var i;
    for (i = 0; i < options.length; i++) {
        if ((options[i] || '').toLowerCase() === w) return i;
    }
    for (i = 0; i < options.length; i++) {
        var o = (options[i] || '').toLowerCase();
        if (o && (o.indexOf(w) !== -1 || w.indexOf(o) !== -1)) return i;
    }
    return -1;
}

function __quizClick(el) {
    el.scrollIntoView({ block: 'nearest' });
    // Click the label when one exists: Moodle wires JS to labels.
    var label = null;
    if (el.id) label = document.querySelector('label[for="' + el.id + '"]');
    if (!label && el.parentElement && (el.parentElement.tagName || '').toLowerCase() === 'label') label = el.parentElement;
    (label || el).click();
    if (!el.checked) { el.click(); }
}

function __quizApplyRadio(root, answer) {
    var radios = __quizCollectRadios(root);
    var labels = [];
    for (var i = 0; i < radios.length; i++) labels.push(radios[i].label);
    var idx = __quizLetterIndex(answer);
    if (idx === -1) idx = __quizFuzzy(labels, answer);
    if (idx < 0 || idx >= radios.length) return { ok: false, verified: false, detail: 'no option matches "' + answer + '"' };
    __quizClick(radios[idx].el);
    return { ok: true, verified: !!radios[idx].el.checked, detail: 'chose "' + labels[idx] + '"' };
}

function __quizApplyChecks(root, answer) {
    var checks = __quizCollectChecks(root);
    var labels = [];
    for (var i = 0; i < checks.length; i++) labels.push(checks[i].label);
    var wants = (answer instanceof Array) ? answer : String(answer).split(',');
    var hit = [];
    for (var w = 0; w < wants.length; w++) {
        var idx = __quizLetterIndex(wants[w]);
        if (idx === -1) idx = __quizFuzzy(labels, wants[w]);
        if (idx >= 0 && idx < checks.length) {
            if (!checks[idx].el.checked) __quizClick(checks[idx].el);
            hit.push(labels[idx]);
        }
    }
    var allOk = true;
    for (var h = 0; h < hit.length; h++) { /* verified below by recount */ }
    var verifiedCount = 0;
    for (var c = 0; c < checks.length; c++) if (checks[c].el.checked) verifiedCount++;
    allOk = hit.length > 0 && verifiedCount >= hit.length;
    return { ok: hit.length > 0, verified: allOk, detail: hit.length ? 'checked ' + hit.join(' | ') : 'nothing matched' };
}

function __quizApplyText(root, answer) {
    var texts = __quizCollectTexts(root);
    if (!texts.length) return { ok: false, verified: false, detail: 'no text field found' };
    var el = texts[0];
    if (el.disabled || el.readOnly) return { ok: false, verified: false, detail: 'field locked (E6)' }; // [E6]
    el.focus();
    __quizSetValue(el, String(answer));
    return { ok: true, verified: el.value === String(answer), detail: 'filled "' + String(answer).slice(0, 60) + '"' };
}

function __quizApplyEssay(root, answer) {
    var areas = __quizCollectAreas(root);
    if (areas.length) {
        var ta = areas[0];
        // [E4] TinyMCE active editor: write through its iframe document.
        try {
            var ed = null;
            if (typeof tinyMCE !== 'undefined' && ta.id && tinyMCE.get(ta.id)) ed = tinyMCE.get(ta.id);
            if (ed) { ed.setContent('<p>' + String(answer).replace(/\n/g, '</p><p>') + '</p>'); ed.save(); }
            else {
                var ifr = document.getElementById(ta.id + '_ifr') || root.querySelector('iframe');
                if (ifr && ifr.contentDocument && ifr.contentDocument.body &&
                    __quizText(ifr.contentDocument.body).length < String(answer).length) {
                    ifr.contentDocument.body.innerHTML = '<p>' + String(answer).replace(/\n/g, '</p><p>') + '</p>';
                }
                __quizSetValue(ta, String(answer));
            }
        } catch (e) { __quizSetValue(ta, String(answer)); }
        return { ok: true, verified: ta.value.length > 0, detail: 'essay pasted (' + ta.value.length + ' chars)' };
    }
    var iframes = root.querySelectorAll('iframe');
    for (var i = 0; i < iframes.length; i++) {
        try {
            var doc = iframes[i].contentDocument;
            if (doc && doc.body && doc.body.isContentEditable !== false) {
                doc.body.focus();
                doc.body.innerHTML = '<p>' + String(answer).replace(/\n/g, '</p><p>') + '</p>';
                return { ok: true, verified: __quizText(doc.body).length > 0, detail: 'rich-text iframe filled' };
            }
        } catch (e) { /* cross-origin: skip */ }
    }
    return { ok: false, verified: false, detail: 'no editable area found' };
}

function __quizApplySelect(root, answer) {
    var sels = __quizCollectSelects(root, false);
    if (!sels.length) return { ok: false, verified: false, detail: 'no dropdown found' };
    var sel = sels[0].el;
    var idx = __quizLetterIndex(answer);
    if (idx !== -1) idx = idx + 1; // +1: placeholder occupies option 0 ([E3])
    else {
        idx = -1;
        for (var i = 0; i < sel.options.length; i++) {
            var t = __quizText(sel.options[i]);
            if (!t || /^(choose|select|--|pick)/i.test(t)) continue;
            if (__quizFuzzy([t], answer) === 0) { idx = i; break; }
        }
    }
    if (idx < 0 || idx >= sel.options.length) return { ok: false, verified: false, detail: 'no option matches "' + answer + '"' };
    sel.selectedIndex = idx;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    return { ok: true, verified: sel.selectedIndex === idx, detail: 'chose "' + __quizText(sel.options[idx]) + '"' };
}

function __quizApplyMatching(root, answer) {
    var sels = __quizCollectSelects(root, false);
    if (!sels.length) return { ok: false, verified: false, detail: 'no matching dropdowns found' };
    var map = answer;
    if (map instanceof Array) { // [[row, option], ...] form
        var o = {};
        for (var k = 0; k < map.length; k++) o[map[k][0]] = map[k][1];
        map = o;
    }
    var trs = root.querySelectorAll('table.answer tr, table.generaltable tr');
    var results = [];
    var selsUsed = 0;
    function applyOne(sel, want) {
        for (var i = 0; i < sel.options.length; i++) {
            var t = __quizText(sel.options[i]);
            if (!t || /^(choose|select|--|pick)/i.test(t)) continue;
            if (__quizFuzzy([t], want) === 0) {
                sel.selectedIndex = i;
                sel.dispatchEvent(new Event('change', { bubbles: true }));
                return sel.selectedIndex === i;
            }
        }
        return false;
    }
    if (trs.length) {
        for (var r = 0; r < trs.length; r++) {
            var sel = trs[r].querySelector('select');
            if (!sel) continue;
            var rowText = __quizText(trs[r].querySelector('.text') || trs[r].firstElementChild);
            // Keys may be row text, or the row's index as string ("0","1"..)
            // for image rows that have no matchable text ([E12]).
            var want = map[String(r)];
            if (typeof want === 'undefined') want = map[rowText];
            if (typeof want === 'undefined') {
                // fallback: fuzzy row key
                for (var key in map) {
                    if (map.hasOwnProperty(key) && __quizFuzzy([rowText], key) === 0) { want = map[key]; break; }
                }
            }
            if (typeof want === 'undefined') { results.push(rowText + ': NO ANSWER SUPPLIED'); continue; }
            results.push(rowText + ': ' + (applyOne(sel, want) ? 'OK' : 'OPTION NOT FOUND'));
            selsUsed++;
        }
    } else {
        // [E7] no table: pair selects to map entries in order.
        var keys = [];
        for (var kk in map) if (map.hasOwnProperty(kk)) keys.push(kk);
        for (var s = 0; s < sels.length && s < keys.length; s++) {
            results.push('row' + s + ': ' + (applyOne(sels[s].el, map[keys[s]]) ? 'OK' : 'OPTION NOT FOUND'));
            selsUsed++;
        }
    }
    var okCount = 0;
    for (var m = 0; m < results.length; m++) if (/: OK$/.test(results[m])) okCount++;
    return { ok: okCount > 0, verified: okCount === results.length && results.length > 0, detail: results.join(' ; ') };
}

function __quizApplyCloze(root, answer) {
    // answer: [{sub:N, answer:"..."}] or plain array in DOM order.
    var list = (answer instanceof Array) ? answer : [];
    var texts = __quizCollectTexts(root);
    var sels = __quizCollectSelects(root, false);
    var results = [];
    var ti = 0, si = 0;
    // Walk subfields in DOM order: merge by document position.
    var fields = [];
    var i;
    for (i = 0; i < texts.length; i++) fields.push({ kind: 'text', el: texts[i] });
    for (i = 0; i < sels.length; i++) fields.push({ kind: 'select', el: sels[i].el });
    fields.sort(function (a, b) {
        var pos = a.el.compareDocumentPosition(b.el);
        return (pos & 2) ? 1 : -1; // Node.DOCUMENT_POSITION_PRECEDING
    });
    for (i = 0; i < fields.length; i++) {
        var item = list[i];
        var want = (item && typeof item === 'object' && 'answer' in item) ? item.answer : item;
        if (typeof want === 'undefined') { results.push('sub' + i + ': NO ANSWER SUPPLIED'); continue; }
        if (fields[i].kind === 'text') {
            if (fields[i].el.disabled || fields[i].el.readOnly) { results.push('sub' + i + ': locked'); continue; }
            __quizSetValue(fields[i].el, String(want));
            results.push('sub' + i + ': ' + (fields[i].el.value === String(want) ? 'OK' : 'SET FAILED'));
        } else {
            var sel = fields[i].el, hit = -1;
            for (var o = 0; o < sel.options.length; o++) {
                var t = __quizText(sel.options[o]);
                if (!t || /^(choose|select|--|pick)/i.test(t)) continue;
                if (__quizFuzzy([t], want) === 0) { hit = o; break; }
            }
            if (hit === -1) { results.push('sub' + i + ': OPTION NOT FOUND'); continue; }
            sel.selectedIndex = hit;
            sel.dispatchEvent(new Event('change', { bubbles: true }));
            results.push('sub' + i + ': ' + (sel.selectedIndex === hit ? 'OK' : 'SET FAILED'));
        }
    }
    var okc = 0;
    for (var q = 0; q < results.length; q++) if (/: OK$/.test(results[q])) okc++;
    return { ok: okc > 0, verified: okc === results.length && results.length > 0, detail: results.join(' ; ') };
}

function __quizApplyDdwtos(root, answer) {
    // answer: array in gap order (["tag","photo",...]) or {0:"...", 2:"..."}.
    // Moodle numbers choices from 1 in drag-item order; grading reads the
    // hidden _pN inputs, so we write those directly and mirror text into the
    // visible gap spans for cosmetic feedback.
    var info = __quizDdwtosInfo(root);
    if (!info.choices.length) return { ok: false, verified: false, detail: 'no drag choices found' };
    var list = [];
    if (answer instanceof Array) list = answer;
    else if (answer && typeof answer === 'object') {
        for (var k in answer) {
            if (answer.hasOwnProperty(k)) list[parseInt(k, 10)] = answer[k];
        }
    } else if (typeof answer !== 'undefined') list = [answer];
    var gaps = root.querySelectorAll('.drop, .gap');
    var all = root.querySelectorAll('input[type="hidden"]');
    var hids = [];
    for (var h = 0; h < all.length; h++) {
        if (/_p\d+$/.test(all[h].name || '')) hids.push(all[h]);
    }
    hids.sort(function (a, b) { return a.name < b.name ? -1 : (a.name > b.name ? 1 : 0); });
    var n = Math.max(gaps.length, hids.length, list.length);
    if (!n) return { ok: false, verified: false, detail: 'no gaps found' };
    var results = [];
    for (var g = 0; g < n; g++) {
        var want = list[g];
        if (typeof want === 'undefined') { results.push('gap' + g + ': NO ANSWER SUPPLIED'); continue; }
        var idx = __quizLetterIndex(want);
        if (idx === -1) idx = __quizFuzzy(info.choices, want);
        if (idx < 0 || idx >= info.choices.length) { results.push('gap' + g + ': CHOICE NOT FOUND'); continue; }
        var val = String(idx + 1);
        if (hids[g]) {
            hids[g].value = val;
            hids[g].dispatchEvent(new Event('change', { bubbles: true }));
            results.push('gap' + g + ': ' + (hids[g].value === val ? 'OK' : 'SET FAILED'));
        } else {
            results.push('gap' + g + ': no hidden field (display only)');
        }
        if (gaps[g]) {
            try {
                gaps[g].innerHTML = '';
                gaps[g].appendChild(document.createTextNode(info.choices[idx]));
            } catch (e) {}
        }
    }
    var okc = 0;
    for (var q = 0; q < results.length; q++) if (/: OK$/.test(results[q])) okc++;
    return { ok: okc > 0, verified: okc === results.length && results.length > 0, detail: results.join(' ; ') };
}

function __quizApplyOne(index, root, answer) {
    var info = __quizClassify(root);
    var res;
    switch (info.answerType) {
        case 'radio_single': res = __quizApplyRadio(root, answer); break;
        case 'checkbox_multi': res = __quizApplyChecks(root, answer); break;
        case 'text_short': res = __quizApplyText(root, answer); break;
        case 'textarea_essay':
        case 'richtext_iframe': res = __quizApplyEssay(root, answer); break;
        case 'select_single': res = __quizApplySelect(root, answer); break;
        case 'matching_multi_select': res = __quizApplyMatching(root, answer); break;
        case 'cloze_mixed': res = __quizApplyCloze(root, answer); break;
        case 'ddwtos_gaps': res = __quizApplyDdwtos(root, answer); break;
        default: return { index: index, ok: false, verified: false, detail: 'unknown answer type' };
    }
    res.index = index;
    res.quizType = info.quizType;
    return res;
}

function __quizImgDataUrl(img, maxSize) {
    // Same-origin icons (Moodle serves them from its own host) can be
    // rasterized to PNG dataURLs. Cross-origin/tainted canvases throw —
    // caller treats '' as "fall back to screenshot crop".
    try {
        if (!img.complete || !img.naturalWidth) return '';
        var w = img.naturalWidth, h = img.naturalHeight;
        var scale = Math.min(1, (maxSize || 128) / Math.max(w, h));
        var c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(w * scale));
        c.height = Math.max(1, Math.round(h * scale));
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        return c.toDataURL('image/png');
    } catch (e) { return ''; }
}

function __quizImgForField(field) {
    var img = null;
    var box = field.parentElement;
    if (box) img = box.querySelector('img');
    if (!img && field.id) {
        var l = document.querySelector('label[for="' + field.id + '"]');
        if (l) img = l.querySelector('img');
    }
    if (!img) {
        try {
            var by = field.getAttribute && field.getAttribute('aria-labelledby');
            if (by) {
                var ref = document.getElementById(by.split(/\s+/)[0]);
                if (ref) img = ref.querySelector('img');
            }
        } catch (e) {}
    }
    return img;
}

function __quizOptionRowImgs(root) {
    // Images already claimed as option/row slots, in DOM order per group.
    // Shared by __quizVisuals (per-slot vision) and __quizContextVisuals
    // (which must EXCLUDE these so figures aren't sent twice).
    var out = [];
    var i, r;
    var fields = root.querySelectorAll('input[type="radio"], input[type="checkbox"]');
    for (i = 0; i < fields.length; i++) {
        out.push({ img: __quizImgForField(fields[i]), kind: 'option', idx: i });
    }
    var trs = root.querySelectorAll('table.answer tr, table.generaltable tr');
    var rn = 0;
    for (r = 0; r < trs.length; r++) {
        if (!trs[r].querySelector('select')) continue;
        out.push({ img: trs[r].querySelector('img'), kind: 'row', idx: rn });
        rn++;
    }
    return out;
}

function __quizVisuals(index) {
    // Returns {index, images:[{slot, kind, row?, opt?, dataUrl}]} for one
    // question. slot = attempt ordinal (stable even when a raster fails);
    // row/opt = the slot's index in detect order. Native addresses slots by
    // row/opt, never by array position.
    var roots = __quizFindRoots();
    var root = roots[index];
    if (!root) return JSON.stringify({ index: index, images: [], detail: 'index out of range' });
    var claimed = __quizOptionRowImgs(root);
    var images = [];
    for (var s = 0; s < claimed.length; s++) {
        var du = claimed[s].img ? __quizImgDataUrl(claimed[s].img) : '';
        if (!du) continue;
        images.push({ slot: s, kind: claimed[s].kind,
            row: claimed[s].kind === 'row' ? claimed[s].idx : -1,
            opt: claimed[s].kind === 'option' ? claimed[s].idx : -1,
            dataUrl: du });
    }
    return JSON.stringify({ index: index, images: images });
}

function __quizContextImageCount(root) {
    var claimed = __quizOptionRowImgs(root);
    var all = root.querySelectorAll('img');
    var n = 0;
    for (var i = 0; i < all.length; i++) {
        var skip = false;
        for (var c = 0; c < claimed.length; c++) {
            if (claimed[c].img === all[i]) { skip = true; break; }
        }
        if (!skip) n++;
    }
    return n;
}

function __quizContextVisuals(index) {
    // Prompt/diagram figures that are NOT option/row slots, stitched into
    // ONE labeled strip (DOM order, left to right, number burned into each
    // panel) so a single vision call sees every figure with its number.
    var roots = __quizFindRoots();
    var root = roots[index];
    if (!root) return JSON.stringify({ index: index, images: [] });
    var claimed = __quizOptionRowImgs(root);
    var seen = [];
    for (var c = 0; c < claimed.length; c++) if (claimed[c].img) seen.push(claimed[c].img);
    var all = root.querySelectorAll('img');
    var figs = [];
    for (var i = 0; i < all.length && figs.length < 4; i++) {
        var img = all[i];
        var skip = false;
        for (var k = 0; k < seen.length; k++) if (seen[k] === img) { skip = true; break; }
        if (skip) continue;
        try {
            if (!img.complete || !img.naturalWidth || img.naturalWidth < 8 || img.naturalHeight < 8) continue;
            if (img.offsetParent === null && (img.offsetWidth || 0) === 0) continue;
        } catch (e) { continue; }
        figs.push(img);
    }
    if (!figs.length) return JSON.stringify({ index: index, images: [] });
    try {
        var maxH = 256, badge = 30, gap = 8;
        var totalW = gap * (figs.length - 1), totalH = 0;
        var dims = [];
        for (var f = 0; f < figs.length; f++) {
            var sc = Math.min(1, maxH / figs[f].naturalHeight);
            var w = Math.max(1, Math.round(figs[f].naturalWidth * sc));
            var h = Math.max(1, Math.round(figs[f].naturalHeight * sc));
            dims.push({ w: w, h: h });
            totalW += w;
            if (h + badge > totalH) totalH = h + badge;
        }
        totalW = Math.min(totalW, 1600);
        var cv = document.createElement('canvas');
        cv.width = totalW;
        cv.height = Math.min(totalH, 900);
        var ctx = cv.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, cv.width, cv.height);
        var x = 0;
        for (var g = 0; g < figs.length; g++) {
            var dw = Math.min(dims[g].w, totalW - x);
            if (dw <= 0) break;
            ctx.fillStyle = '#111111';
            ctx.font = 'bold 20px sans-serif';
            ctx.fillText(String(g + 1), x + 4, 22);
            try { ctx.drawImage(figs[g], x, badge, dw, dims[g].h); }
            catch (e) { return JSON.stringify({ index: index, images: [] }); }
            x += dw + gap;
        }
        return JSON.stringify({ index: index, images: [{ slot: 0, kind: 'context', row: -1, opt: -1, dataUrl: cv.toDataURL('image/png') }] });
    } catch (e) { return JSON.stringify({ index: index, images: [] }); }
}

function __quizApply(itemsJson) {
    // items: [{index:N, answer:...}] — index = value from __quizDetect.
    // Roots are re-queried on every call so navigation/re-render between
    // detect and apply can't misalign (detect-then-apply may be two
    // separate EvaluateScriptAsync round-trips from native).
    var items;
    try { items = (typeof itemsJson === 'string') ? JSON.parse(itemsJson) : itemsJson; }
    catch (e) { return JSON.stringify({ ok: false, results: [], detail: 'bad payload JSON' }); }
    if (!(items instanceof Array)) items = [items];
    var roots = __quizFindRoots();
    var results = [];
    for (var i = 0; i < items.length; i++) {
        var idx = items[i].index;
        if (typeof idx === 'undefined') idx = __quizRootOfFocused(roots);
        if (idx === -1) idx = 0;
        if (!roots[idx]) { results.push({ index: idx, ok: false, verified: false, detail: 'index out of range' }); continue; }
        results.push(__quizApplyOne(idx, roots[idx], items[i].answer));
    }
    return JSON.stringify({ ok: true, results: results });
}
